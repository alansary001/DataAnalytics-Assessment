# Data Analytics Assessment

This README contains explanations for the four SQL tasks.
