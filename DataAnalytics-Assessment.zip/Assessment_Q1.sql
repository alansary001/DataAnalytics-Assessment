-- Sample content for Q1
SELECT * FROM dummy_table;