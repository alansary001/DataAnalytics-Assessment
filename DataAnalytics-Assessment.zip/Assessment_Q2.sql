-- Sample content for Q2
SELECT * FROM dummy_table;