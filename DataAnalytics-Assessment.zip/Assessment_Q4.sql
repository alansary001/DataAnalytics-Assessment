-- Sample content for Q4
SELECT * FROM dummy_table;