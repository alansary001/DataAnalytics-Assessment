-- Sample content for Q3
SELECT * FROM dummy_table;